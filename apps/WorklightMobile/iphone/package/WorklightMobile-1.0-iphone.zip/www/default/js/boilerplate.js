
/* JavaScript content from js/boilerplate.js in folder common */
define([
  'jQuery',
  'Underscore',
  'Backbone'
], function($, _, Backbone){

  return {};
});
